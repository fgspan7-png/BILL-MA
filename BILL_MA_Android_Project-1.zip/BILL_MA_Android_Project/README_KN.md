BILL MA Android project (source project, not a compiled APK)

Included:
- Android Studio project using Kotlin + Android WebView
- Existing BILL MA MVP web interface bundled locally for offline launch
- Android file picker bridge for PDF/JPG/PNG bill selection
- App label: BILL MA

Build APK:
1. Install Android Studio on a Windows/Mac/Linux computer.
2. Extract BILL_MA_Android_Project.zip.
3. Android Studio > Open > select the extracted BILL_MA_Android_Project folder.
4. Wait for Gradle sync and install the Android SDK Platform 35 if prompted.
5. Build > Build Bundle(s) / APK(s) > Build APK(s).
6. Android Studio will show the APK location (usually app/build/outputs/apk/debug/app-debug.apk).
7. Transfer that APK to the Android phone and install it. Allow installation from that file source if Android asks.

Important limitations:
- This archive is Android source code; no compiled APK is included because this environment does not have the Android SDK/Gradle build toolchain.
- The bundled BILL MA MVP is a prototype. It uses browser local storage on this device; it does not provide secure production authentication, cloud sync, complete accounting, GST filing, or automatic OCR extraction.
- The scanner screen currently lets the user select source files; it does not read invoice fields automatically.
- Do not use the demo credentials or prototype for confidential or statutory business records.
